# KERDEX Beta 1.0 — demonstração interativa

## Abrir
Abra `index.html` em um navegador moderno. Nenhuma instalação, conta ou conexão com servidor é necessária.

## Incluído
- Landing page institucional e navegação interna responsiva
- Dashboard com receitas, despesas e saldo de período **demonstrativo**
- Cadastro/remoção em memória de movimentações, compras planejadas e metas
- Calculadora simples de poupança
- Português brasileiro e inglês; formatação BRL/USD/EUR **sem conversão cambial**
- Layouts para celular, tablet e desktop; estados de foco e controles semânticos básicos

## Limitações importantes
- Protótipo estático, **não** aplicativo financeiro pronto para produção.
- Não possui backend, autenticação, banco de dados, sincronização, backups ou auditoria.
- Não persiste dados: recarregar a página restaura dados fictícios. Não insira informações financeiras reais.
- O gráfico apresenta um resumo simples do conjunto de transações de demonstração, não séries históricas reais.
- A formatação de moedas não converte valores.
- Não foi submetido a pentest, auditoria de acessibilidade ou validação de conformidade.

## Segurança existente
- Sem serviços externos ou chamadas de rede do JavaScript.
- Textos do usuário escapados antes da inserção em HTML.
- Valores numéricos validados no cliente, apenas para demonstração.
- Nenhum token, segredo, senha ou dado financeiro real incluído.

## Antes de produção
1. Aplicação com backend e autenticação gerenciada, sessões protegidas e MFA/passkeys.
2. Controle de acesso no servidor em toda operação e isolamento entre usuários.
3. Banco PostgreSQL com políticas de acesso, migrações, backups, testes de restauração e trilhas de auditoria.
4. Validação e autorização no servidor, proteção contra CSRF conforme arquitetura, XSS, abuso, enumeração e rate limiting.
5. Criptografia em trânsito, gestão de segredos, logs sem dados sensíveis e monitoramento.
6. Modelagem monetária com inteiros em unidades mínimas ou DECIMAL, nunca floats de JavaScript como livro-razão.
7. Política de privacidade, base legal LGPD, minimização e retenção de dados, exclusão/exportação.
8. Revisão de dependências, CI, testes automatizados, análise estática, pentest e resposta a incidentes.
9. Internacionalização real: locale, timezone, currency por transação, conversão com taxa/fonte/data, regras por jurisdição.
10. Verificação de licença de dados financeiros e avaliação regulatória antes de recomendações ou execução de ordens.

## Arquitetura futura sugerida
- Frontend: Next.js/React + TypeScript + design tokens
- API: módulos `identity`, `ledger`, `goals`, `purchase-planning`, `preferences`, `audit`
- Banco: PostgreSQL com isolamento multiusuário
- Serviços externos através de adaptadores; nunca expor chaves no frontend
- Internacionalização desde o início com IDs de tradução, locale, moeda e timezone

## Design
Diretrizes derivadas do briefing de identidade KERDEX fornecido pelo usuário. Verde institucional #102B22; destaque #C8F35A; superfícies #F7F9F6.
